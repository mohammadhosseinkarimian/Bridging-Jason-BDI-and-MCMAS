# custom2_two_location_two_agent

Two connected locations are used:

- **area 1**: a concrete refuge. FireBrigade and AmbulanceTeam start here.
- **area 2**: a wooden collapsed building containing civilian `Civ`.

Initial rescue state:

- Civ HP: 7500 (`high`)
- Civ damage: 2500
- Civ buriedness: 1, so one FireBrigade rescue action makes Civ surface-level
- health damage applies only while Civ remains buried in the collapsed building

Intended Jason-guided coordination:

1. FireBrigade and AmbulanceTeam move from area 1 to area 2.
2. FireBrigade rescues Civ; AmbulanceTeam waits. Civ becomes surface-level and `at_risk`.
3. AmbulanceTeam loads Civ while FireBrigade performs the ready notification.
4. AmbulanceTeam returns to refuge area 1.
5. AmbulanceTeam unloads Civ alive.

`initial.json` is the input configuration for the exact raw translator and the exact two-agent Jason-guided translation branch.
