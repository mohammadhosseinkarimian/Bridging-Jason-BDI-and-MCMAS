<?xml version="1.0" encoding="UTF-8"?>

<rcr:map xmlns:rcr="urn:roborescue:map:gml"
         xmlns:xlink="http://www.w3.org/1999/xlink"
         xmlns:gml="http://www.opengis.net/gml">
  <rcr:nodelist>
    <gml:Node gml:id="101"><gml:pointProperty><gml:Point><gml:coordinates>0,0</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
    <gml:Node gml:id="102"><gml:pointProperty><gml:Point><gml:coordinates>8,0</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
    <gml:Node gml:id="103"><gml:pointProperty><gml:Point><gml:coordinates>16,0</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
    <gml:Node gml:id="104"><gml:pointProperty><gml:Point><gml:coordinates>16,8</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
    <gml:Node gml:id="105"><gml:pointProperty><gml:Point><gml:coordinates>8,8</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
    <gml:Node gml:id="106"><gml:pointProperty><gml:Point><gml:coordinates>0,8</gml:coordinates></gml:Point></gml:pointProperty></gml:Node>
  </rcr:nodelist>

  <rcr:edgelist>
    <gml:Edge gml:id="201"><gml:directedNode orientation="-" xlink:href="#101"/><gml:directedNode orientation="+" xlink:href="#102"/></gml:Edge>
    <gml:Edge gml:id="202"><gml:directedNode orientation="-" xlink:href="#102"/><gml:directedNode orientation="+" xlink:href="#105"/></gml:Edge>
    <gml:Edge gml:id="203"><gml:directedNode orientation="-" xlink:href="#105"/><gml:directedNode orientation="+" xlink:href="#106"/></gml:Edge>
    <gml:Edge gml:id="204"><gml:directedNode orientation="-" xlink:href="#106"/><gml:directedNode orientation="+" xlink:href="#101"/></gml:Edge>
    <gml:Edge gml:id="205"><gml:directedNode orientation="-" xlink:href="#102"/><gml:directedNode orientation="+" xlink:href="#103"/></gml:Edge>
    <gml:Edge gml:id="206"><gml:directedNode orientation="-" xlink:href="#103"/><gml:directedNode orientation="+" xlink:href="#104"/></gml:Edge>
    <gml:Edge gml:id="207"><gml:directedNode orientation="-" xlink:href="#104"/><gml:directedNode orientation="+" xlink:href="#105"/></gml:Edge>
  </rcr:edgelist>

  <rcr:buildinglist>
    <!-- area 1: concrete refuge; FireBrigade and AmbulanceTeam start here -->
    <rcr:building gml:id="1">
      <gml:Face rcr:floors="1" rcr:buildingcode="2" rcr:importance="1">
        <gml:directedEdge orientation="+" xlink:href="#201"/>
        <gml:directedEdge orientation="+" xlink:href="#202" rcr:neighbour="2"/>
        <gml:directedEdge orientation="+" xlink:href="#203"/>
        <gml:directedEdge orientation="+" xlink:href="#204"/>
      </gml:Face>
    </rcr:building>

    <!-- area 2: wooden collapsed building containing Civ -->
    <rcr:building gml:id="2">
      <gml:Face rcr:floors="1" rcr:buildingcode="0" rcr:importance="1">
        <gml:directedEdge orientation="+" xlink:href="#205"/>
        <gml:directedEdge orientation="+" xlink:href="#206"/>
        <gml:directedEdge orientation="+" xlink:href="#207"/>
        <gml:directedEdge orientation="-" xlink:href="#202" rcr:neighbour="1"/>
      </gml:Face>
    </rcr:building>
  </rcr:buildinglist>

  <rcr:roadlist/>
</rcr:map>
